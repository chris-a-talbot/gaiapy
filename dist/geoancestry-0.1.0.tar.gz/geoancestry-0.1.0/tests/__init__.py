"""
Test suite for gaiapy
"""
